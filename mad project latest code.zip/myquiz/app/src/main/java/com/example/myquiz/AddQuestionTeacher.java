/*package com.example.myquiz;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class AddQuestionTeacher extends AppCompatActivity {
String a,b,c,d,e;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.adding_question);
        EditText et1=(EditText)findViewById(R.id.editText);
        EditText et2=(EditText)findViewById(R.id.editText2);
        EditText et3=(EditText)findViewById(R.id.editText3);
        EditText et4=(EditText)findViewById(R.id.editText4);
        EditText et5=(EditText)findViewById(R.id.editText5);
        Button bt=(Button)findViewById(R.id.button3);
        Button back=(Button)findViewById(R.id.button6);
        a=et1.getText().toString();
        b=et2.getText().toString();
        c=et3.getText().toString();
        d=et4.getText().toString();
        e=et5.getText().toString();
        bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(a.isEmpty()||b.isEmpty()||c.isEmpty()||d.isEmpty()||e.isEmpty())
                {
                    Toast.makeText(AddQuestionTeacher.this, "Please enter all the fields!", Toast.LENGTH_SHORT).show();
                }
                else
                    {


                }
            }
        });
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(AddQuestionTeacher.this,TeacherOptionPage.class);
                startActivity(intent);
            }
        });

    }

}
*/
package com.example.myquiz;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class AddQuestionTeacher extends AppCompatActivity {
    String a,b,c,d,e;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.adding_question);
        EditText et1=(EditText)findViewById(R.id.etquestion);
        EditText et2=(EditText)findViewById(R.id.etopt1);
        EditText et3=(EditText)findViewById(R.id.etopt2);
        EditText et4=(EditText)findViewById(R.id.etopt3);
        EditText et5=(EditText)findViewById(R.id.etanswer);
        Button bt=(Button)findViewById(R.id.submit_question);
        Button back=(Button)findViewById(R.id.back);
        a=et1.getText().toString();
        b=et2.getText().toString();
        c=et3.getText().toString();
        d=et4.getText().toString();
        e=et5.getText().toString();
        bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(a.isEmpty()||b.isEmpty()||c.isEmpty()||d.isEmpty()||e.isEmpty())
                {
                    Toast.makeText(AddQuestionTeacher.this, "Please enter all the fields!", Toast.LENGTH_SHORT).show();
                }
                else
                {


                }
            }
        });
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(AddQuestionTeacher.this,TeacherOptionPage.class);
                startActivity(intent);
            }
        });

    }
}
