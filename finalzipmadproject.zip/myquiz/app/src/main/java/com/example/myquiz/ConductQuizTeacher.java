/*package com.example.myquiz;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class ConductQuizTeacher extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.conduct_quiz_teacher);
        final SharedPreferences sh = getSharedPreferences("QuizStatus", Context.MODE_PRIVATE);
        final SharedPreferences.Editor myEdit = sh.edit();
        final RadioGroup choice = (RadioGroup)findViewById(R.id.choice);
        Button b =(Button)findViewById(R.id.button);
        Button back=(Button)findViewById(R.id.button6) ;
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int c=choice.getCheckedRadioButtonId();
                RadioButton r=(RadioButton)findViewById(c);
                /*if(!(r.isChecked())){
                    Toast.makeText(Main6Activity.this,"Please select an option",Toast.LENGTH_SHORT).show();
                }
                if (r.getText().equals("yes")){
                    myEdit.putInt("Quiz Status",1);
                    myEdit.apply();
                    Toast.makeText(ConductQuizTeacher.this, "Quiz is now active", Toast.LENGTH_LONG).show();
                }
                else{
                    myEdit.putInt("Quiz Status",0);
                    myEdit.commit();
                    Toast.makeText(ConductQuizTeacher.this, "Oops! Quiz is no longer active", Toast.LENGTH_LONG).show();
                }


            }
        });
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(ConductQuizTeacher.this,TeacherOptionPage.class);
                startActivity(intent);
            }
        });

    }
}
*/
package com.example.myquiz;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class ConductQuizTeacher extends AppCompatActivity {
    DatePicker simpleDatePicker;
    Button submit;
    EditText e;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.conduct_quiz_teacher);
        /*final SharedPreferences sh = getSharedPreferences("QuizStatus", Context.MODE_PRIVATE);
        final SharedPreferences.Editor myEdit = sh.edit();
        final RadioGroup choice = (RadioGroup)findViewById(R.id.choice);
        Button b =(Button)findViewById(R.id.button);
        Button back=(Button)findViewById(R.id.button6) ;
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int c=choice.getCheckedRadioButtonId();
                RadioButton r=(RadioButton)findViewById(c);
                /*if(!(r.isChecked())){
                    Toast.makeText(Main6Activity.this,"Please select an option",Toast.LENGTH_SHORT).show();
                }
                if (r.getText().equals("yes")){
                    myEdit.putInt("Quiz Status",1);
                    myEdit.apply();
                    Toast.makeText(ConductQuizTeacher.this, "Quiz is now active", Toast.LENGTH_LONG).show();
                }
                else{
                    myEdit.putInt("Quiz Status",0);
                    myEdit.commit();
                    Toast.makeText(ConductQuizTeacher.this, "Oops! Quiz is no longer active", Toast.LENGTH_LONG).show();
                }


            }
        });
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(ConductQuizTeacher.this,TeacherOptionPage.class);
                startActivity(intent);
            }
        });*/
        // initiate the date picker and a button
        simpleDatePicker = (DatePicker) findViewById(R.id.simpleDatePicker);
        submit = (Button) findViewById(R.id.submitButton);
        e=(EditText) findViewById(R.id.editText);
        SharedPreferences mySharedPref=getSharedPreferences("myData", Context.MODE_PRIVATE);
        final SharedPreferences.Editor editor=mySharedPref.edit();
        // perform click event on submit button
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // get the values for day of month , month and year from a date picker
                String day = "Day = " + simpleDatePicker.getDayOfMonth();
                String month = "Month = " + (simpleDatePicker.getMonth() + 1);
                String year = "Year = " + simpleDatePicker.getYear();
                String time=e.getText().toString();
                editor.putString("Day",day);
                editor.putString("Month",month);
                editor.putString("Year",year);
                editor.putString("Time",time);
                editor.commit();
                // display the values by using a toast
                Toast.makeText(getApplicationContext(), "Quiz Scheduled for "+day + "\t" + month + "\t" + year + "\n" + time + "hours", Toast.LENGTH_LONG).show();
            }
        });

    }
}

