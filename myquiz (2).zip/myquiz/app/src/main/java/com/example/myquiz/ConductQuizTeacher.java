package com.example.myquiz;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class ConductQuizTeacher extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.conduct_quiz_teacher);
        final SharedPreferences sh = getSharedPreferences("QuizStatus", Context.MODE_PRIVATE);
        final SharedPreferences.Editor myEdit = sh.edit();
        final RadioGroup choice = (RadioGroup)findViewById(R.id.choice);
        Button b =(Button)findViewById(R.id.button);

        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int c=choice.getCheckedRadioButtonId();
                RadioButton r=(RadioButton)findViewById(c);
                /*if(!(r.isChecked())){
                    Toast.makeText(Main6Activity.this,"Please select an option",Toast.LENGTH_SHORT).show();
                }*/
                if (r.getText().equals("yes")){
                    myEdit.putInt("Quiz Status",1);
                    myEdit.apply();
                    Toast.makeText(ConductQuizTeacher.this, "Quiz is now active", Toast.LENGTH_LONG).show();
                }
                else{
                    myEdit.putInt("Quiz Status",0);
                    myEdit.commit();
                    Toast.makeText(ConductQuizTeacher.this, "Oops! Quiz is no longer active", Toast.LENGTH_LONG).show();
                }


            }
        });
    }
}
